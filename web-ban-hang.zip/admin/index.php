<?php
	$title = 'Dashboard Page';
	$baseUrl = '';
	require_once('layouts/header.php');
?>
<body style = "background-image: url(../assets/image/dashboard.jpg); background-size: cover; background-repeat: no-repeat;">
<div class="row">
	<div class="col-md-12">
	</div>
</div>
</body>
<?php
	require_once('layouts/footer.php');
?>