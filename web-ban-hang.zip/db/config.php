<?php
define('HOST','localhost');
define('DATABASE','webbanhang');
define('USERNAME','root');
define('PASSWORD','');
define('PRIVATE_KEY','345g1+1+5+5$%TB*GJ8^V');